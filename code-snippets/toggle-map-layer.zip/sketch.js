// This code example shows how to preload data layers and change their visibility using the checkbox function.
// Emily Deardorff, 10/13/21
// https://github.com/EmilyDeardorff/explore-hydrology-p5js/

canvW = 400; // dimensions of canvas
canvH = 400;

checkX = 10; // location of checkboxes
checkY = 10;

function preload() {
  lyr1 = loadImage("data/terrain.png");
  lyr2 = loadImage("data/buildings_red.png");
}

function setup() {
  createCanvas(canvW, canvH);

  check1 = createCheckbox(" Terrain", true); // true means the checkbox is checked when the sketch is loaded, so the terrain layer pops up upon loading
  check1.position(checkX, checkY);

  check2 = createCheckbox(" Buildings", false); // false means the checkbox is not checked when the sketch is loaded
  check2.position(checkX, checkY + 20);
}

function draw() {
  background(220);
  toggleLayer1(); // show checkbox layers if they are selected
  toggleLayer2();
}

function toggleLayer1() {
  if (check1.checked()) {
    image(lyr1, 0, 0, canvW, canvH);
  }
}

function toggleLayer2() {
  if (check2.checked()) {
    image(lyr2, 0, 0, canvW, canvH);
  }
}
